#include <stdio.h>
#include <math.h>

void solver(float a, float b, float c, float* rishe1, float* rishe2) {
    float delta = b * b - 4 * a * c;
    
    if (delta > 0) {
        *rishe1 = (-b + sqrt(delta)) / (2 * a);
        *rishe2 = (-b - sqrt(delta)) / (2 * a);
    }
    else if (delta == 0) {
        *rishe1 = *rishe2 = -b / (2 * a);
    }
}

int main() {
    float a, b, c;
    float rishe1, rishe2;

    printf("Enter zarayeb (a, b, c): ");
    scanf("%f %f %f", &a, &b, &c);

    solver(a, b, c, &rishe1, &rishe2);

    if ((a == 0) && (b == 0) && (c == 0)) {
        printf("bishomar javab \n");
    }
    else if (a == 0) {
        printf("moadele daraje 2 nist\n");
    }
    else if (c == 0) {
        printf("Rishe 1: 0.0\n");
        printf("Rishe 2: %.2f\n", rishe2);
    }
    else if (rishe1 && rishe2) {
        printf("Rishe 1: %.2f\n", rishe1);
        printf("Rishe 2: %.2f\n", rishe2);
    }
    else {
        printf("moadele javab haghighi nadarad \n");
    }

    return 0;
}